﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TelerikEditors
{
    /// <summary>
    /// Interaction logic for ComboBoxDemo.xaml
    /// </summary>
    public partial class ComboBoxDemo : Window
    {
        public ComboBoxDemo()
        {
            InitializeComponent();
        }
    }

    public class Person
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string City { get; set; }
    }

    public class PersonViewModel
    {
        public ObservableCollection<Person> People { get; set; }

        public PersonViewModel()
        {
            this.People = new ObservableCollection<Person> { 
            new Person{FirstName="Ajinkya", LastName="Jagtap", City="Pune"},
            new Person{FirstName="Ajit", LastName="Pawar", City="Baramati"},
            new Person{FirstName="Ajitha", LastName="Manke", City="Nagar"},
            new Person{FirstName="Amol", LastName="Jagtap", City="Saswad"},
            new Person{FirstName="Amit", LastName="Saste", City="Pune"},
            new Person{FirstName="Amar", LastName="Jagtap", City="Mumbai"},
            new Person{FirstName="Anmol", LastName="Kadam", City="Pune"}};
        }
    }
}