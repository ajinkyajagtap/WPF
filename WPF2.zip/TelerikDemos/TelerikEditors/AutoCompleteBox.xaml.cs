﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TelerikEditors
{
    /// <summary>
    /// Interaction logic for AutoCompleteBox.xaml
    /// </summary>
    public partial class AutoCompleteBox : Window
    {
        public AutoCompleteBox()
        {
            InitializeComponent();
        }
    }

    public class Employee
    {
        public string FullName { get; set; }
    }

    public class ViewModel
    {
        public ObservableCollection<Employee> Employees { get; set; }

        public ViewModel()
        {
            this.Employees = new ObservableCollection<Employee> { 
            new Employee{FullName="Ajinkya"},
            new Employee{FullName="Ajit"},
            new Employee{FullName="Ajitha"},
            new Employee{FullName="Amol"},
            new Employee{FullName="Amit"},
            new Employee{FullName="Amar"},
            new Employee{FullName="Anmol"}};
        }
    }
}
