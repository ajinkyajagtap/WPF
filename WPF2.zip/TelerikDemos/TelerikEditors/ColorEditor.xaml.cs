﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TelerikEditors
{
    /// <summary>
    /// Interaction logic for ColorEditor.xaml
    /// </summary>
    public partial class ColorEditor : Window
    {
        public ColorEditor()
        {
            InitializeComponent();
        }

        private void RadColorEditor_SelectedColorChanged(object sender, Telerik.Windows.Controls.ColorEditor.ColorChangeEventArgs e)
        {
            txtDemo.Foreground = new System.Windows.Media.SolidColorBrush(colorEditor.SelectedColor); 
        }

        private void RadColorPicker_SelectedColorChanged(object sender, EventArgs e)
        {
            MessageBox.Show(colorPicker.SelectedColor.ToString());
        }
    }
}