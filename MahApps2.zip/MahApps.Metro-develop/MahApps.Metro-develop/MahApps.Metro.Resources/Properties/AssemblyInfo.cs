﻿using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows;

[assembly: AssemblyCopyright("Copyright © MahApps.Metro 2011-2016")]
[assembly: ComVisible(false)]

[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]

[assembly: AssemblyVersion("0.5.0.0")]
[assembly: AssemblyFileVersion("0.5.0.0")]
[assembly: AssemblyInformationalVersion("0.5.0.0")]
[assembly: AssemblyTitle("MahApps.Metro.Resources")]
[assembly: AssemblyDescription("XAML icon resource for creating Metro styled WPF apps")]
[assembly: AssemblyProduct("MahApps.Metro.Resources 0.5.0")]
[assembly: AssemblyCompany("MahApps")]
