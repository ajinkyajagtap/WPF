﻿using MahApps.Metro.Controls;

namespace Caliburn.Metro.Demo.ViewModels.Flyouts
{
    public class Flyout1ViewModel : FlyoutBaseViewModel
    {
        public Flyout1ViewModel()
        {
            this.Header = "settings";
            this.Position = Position.Right;
        }
    }
}