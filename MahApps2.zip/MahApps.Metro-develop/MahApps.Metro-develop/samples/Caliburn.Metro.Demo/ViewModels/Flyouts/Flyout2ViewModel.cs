﻿using MahApps.Metro.Controls;

namespace Caliburn.Metro.Demo.ViewModels.Flyouts
{
    public class Flyout2ViewModel : FlyoutBaseViewModel
    {
        public Flyout2ViewModel()
        {
            this.Header = "new goodness";
            this.Position = Position.Right;
        }
    }
}