﻿namespace MahApps.Metro.Tests
{
    public partial class CleanWindow
    {
        public CleanWindow()
        {
            InitializeComponent();
        }
    }
}
