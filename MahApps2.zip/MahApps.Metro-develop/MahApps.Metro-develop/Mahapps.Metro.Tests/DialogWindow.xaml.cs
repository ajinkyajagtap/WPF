﻿namespace MahApps.Metro.Tests
{
    public partial class DialogWindow 
    {
        public DialogWindow()
        {
            InitializeComponent();
        }
    }
}
