﻿using System.Collections.Generic;

namespace MahApps.Metro.Controls
{
    /// ******************************************
    /// This code is auto generated. Do not amend.
    /// ******************************************

    internal static class PackIconMaterialDataFactory
    {
        internal static IDictionary<PackIconMaterialKind, string> Create()
        {
            return new Dictionary<PackIconMaterialKind, string>
                   {
                   };
        }
    }
}
