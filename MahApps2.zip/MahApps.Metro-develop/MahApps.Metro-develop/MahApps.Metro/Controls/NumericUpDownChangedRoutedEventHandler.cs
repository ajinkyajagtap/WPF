﻿namespace MahApps.Metro.Controls
{
    public delegate void NumericUpDownChangedRoutedEventHandler(object sender, NumericUpDownChangedRoutedEventArgs args);
}
