﻿using System;

namespace MahApps.Metro.Native
{
    [Obsolete("Use Standard.ABEdge instead.")]
    internal enum ABEdge
    {
        ABE_LEFT = 0,
        ABE_TOP = 1,
        ABE_RIGHT = 2,
        ABE_BOTTOM = 3
    }
}
