﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RoutedEventsDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Debug.WriteLine("Window_MouseDown");
        }

        private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Debug.WriteLine("Grid_MouseDown");
        }

        private void GroupBox_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Debug.WriteLine("GroupBox_MouseDown");
        }

        private void StackPanel_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Debug.WriteLine("StackPanel_MouseDown");
        }

        private void Window_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            Debug.WriteLine("Window_PreviewMouseDown");
        }

        private void Grid_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            Debug.WriteLine("Grid_PreviewMouseDown");
        }

        private void GroupBox_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            Debug.WriteLine("GroupBox_PreviewMouseDown");
        }

        private void StackPanel_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            Debug.WriteLine("StackPanel_PreviewMouseDown");
            e.Handled = true;
        }
    }
}
