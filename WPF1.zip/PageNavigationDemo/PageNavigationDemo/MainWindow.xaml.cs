﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PageNavigationDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            ThicknessAnimation ta = new ThicknessAnimation();
            //your first place
            ta.From = grid1.Margin;
            //this move your grid 1000 over from left side
            //you can use -1000 to move to left side
            ta.To = new Thickness(301, 0, 601, 300);
            //time the animation playes
            ta.Duration = new Duration(TimeSpan.FromSeconds(2));
            //dont need to use story board but if you want pause,stop etc use story board
            
            grid1.BeginAnimation(Page.MarginProperty, ta);
            grid2.Visibility = System.Windows.Visibility.Visible;

            ThicknessAnimation t2 = new ThicknessAnimation();
            //your first place
            t2.From = grid2.Margin;
            //this move your grid 1000 over from left side
            //you can use -1000 to move to left side
            t2.To = new Thickness(0, 0, 300, 300);
            //time the animation playes
            t2.Duration = new Duration(TimeSpan.FromSeconds(2));
            //dont need to use story board but if you want pause,stop etc use story board
            //secondPage.Visibility = System.Windows.Visibility.Visible;
            grid2.BeginAnimation(Grid.MarginProperty, t2);
        }

        private void btnGoToFirstPage_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
