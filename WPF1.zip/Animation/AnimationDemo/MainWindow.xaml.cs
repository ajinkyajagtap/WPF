﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AnimationDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.Loaded += MainWindow_Loaded;
        }

        void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            DoubleAnimation aniWidth = new DoubleAnimation();
            aniWidth.From = 75;
            aniWidth.To = 150;
            aniWidth.Duration = TimeSpan.Parse("0:0:5");

            DoubleAnimation aniHeight = new DoubleAnimation();
            aniHeight.From = 75;
            aniHeight.To = 150;
            aniHeight.Duration = TimeSpan.Parse("0:0:5");

            DoubleAnimation aniFont = new DoubleAnimation();
            aniFont.From = 10;
            aniFont.To = 96;
            aniFont.Duration = TimeSpan.Parse("0:0:5");

            Storyboard sb = new Storyboard();
            sb.Children.Add(aniWidth);
            sb.Children.Add(aniHeight);
            sb.Children.Add(aniFont);

            Storyboard.SetTargetName(aniWidth, "btn");
            Storyboard.SetTargetProperty(aniWidth, new PropertyPath(Button.WidthProperty));

            Storyboard.SetTargetName(aniHeight, "btn");
            Storyboard.SetTargetProperty(aniHeight, new PropertyPath(Button.HeightProperty));

            Storyboard.SetTargetName(aniFont, "btn");
            Storyboard.SetTargetProperty(aniFont, new PropertyPath(Button.FontSizeProperty));

            sb.Begin(btn);

            //btn.BeginAnimation(WidthProperty, ani);
            //btn.BeginAnimation(HeightProperty, ani);
        }
    }
}
