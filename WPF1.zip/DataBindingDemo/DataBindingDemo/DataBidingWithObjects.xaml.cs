﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataBindingDemo
{
    /// <summary>
    /// Interaction logic for DataBidingWithObjects.xaml
    /// </summary>
    public partial class DataBidingWithObjects : Window
    {
        public DataBidingWithObjects()
        {
            InitializeComponent();
            Employee emp = new Employee { FirstName = "Jet", LastName = "Li" };
            gridEmployee.DataContext = emp;

            Employee emp1 = new Employee { FirstName="A", LastName="B"};
            Employee emp2 = new Employee { FirstName = "C", LastName = "D" };
            Employee emp3 = new Employee { FirstName = "E", LastName = "F" };
            List<Employee> emps = new List<Employee> { emp1, emp2, emp3};

            listEmps.ItemsSource = emps;
            listEmps.DisplayMemberPath = "FirstName";
            //this.Loaded += DataBidingWithObjects_Loaded;
        }

        //This is 1 way of binding the objects through C#
        //void DataBidingWithObjects_Loaded(object sender, RoutedEventArgs e)
        //{
        //    Employee emp = new Employee { FirstName="Jet", LastName="Li"};
        //    Binding bFirstName = new Binding();
        //    bFirstName.Source = emp;
        //    bFirstName.Path = new PropertyPath("FirstName");
        //    tbkFName.SetBinding(TextBlock.TextProperty, bFirstName);

        //    Binding bLastName = new Binding("LastName");
        //    bLastName.Source = emp;
        //    tbkLName.SetBinding(TextBlock.TextProperty, bLastName);
        //}

        //This is 2nd way of binding the objects through C#
        //void DataBidingWithObjects_Loaded(object sender, RoutedEventArgs e)
        //{
        //    Employee emp = new Employee { FirstName = "Jet", LastName = "Li" };
        //    gridEmployee.DataContext = emp;
        //    Binding bFirstName = new Binding();
        //    bFirstName.Path = new PropertyPath("FirstName");
        //    tbkFName.SetBinding(TextBlock.TextProperty, bFirstName);

        //    Binding bLastName = new Binding();
        //    bLastName.Path = new PropertyPath("LastName");
        //    tbkLName.SetBinding(TextBlock.TextProperty, bLastName);
        //}
    }

    public class Employee
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}