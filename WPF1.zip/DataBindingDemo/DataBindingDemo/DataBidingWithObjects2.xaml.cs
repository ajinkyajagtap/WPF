﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Collections.ObjectModel;

namespace DataBindingDemo
{
    /// <summary>
    /// Interaction logic for DataBidingWithObjects2.xaml
    /// </summary>
    public partial class DataBidingWithObjects2 : Window
    {
        Employee2 emp = null;
        ObservableCollection<Employee2> emps;

        public DataBidingWithObjects2()
        {
            InitializeComponent();
            this.Loaded += DataBidingWithObjects2_Loaded;
        }

        void DataBidingWithObjects2_Loaded(object sender, RoutedEventArgs e)
        {
            emp = new Employee2 { FirstName = "Ajinkya", LastName = "Jagtap" };
            sp.DataContext = emp;

            emps = new ObservableCollection<Employee2> { 
            new Employee2{FirstName="Ajay", LastName="Kumbharkar"},
            new Employee2{FirstName="Ajit", LastName="Bhate"}
            };
            listEmps.ItemsSource = emps;
            listEmps.DisplayMemberPath = "FullName";
        }

        private void CheckName_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(emp.FirstName + " " + emp.LastName);
        }

        private void ChangeName_Click(object sender, RoutedEventArgs e)
        {
            emp.FirstName = "Aditya";
            emp.LastName = "Kadam";
        }
    }

    public class Employee2 : INotifyPropertyChanged
    {
        private string firstName;

        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; OnPropertyChanged("FirstName"); }
        }

        private string lastName;

        public string LastName
        {
            get { return lastName; }
            set { lastName = value; OnPropertyChanged("LastName"); }
        }

        public string FullName
        {
            get { return firstName + " " + lastName; }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propName)
        {
            if(PropertyChanged!= null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propName));
            }
        }
    }
}