﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace StylesDemo
{
    /// <summary>
    /// Interaction logic for ComplexObjects.xaml
    /// </summary>
    public partial class ComplexObjects : Window
    {
        public ComplexObjects()
        {
            InitializeComponent();
            this.Loaded += ComplexObjects_Loaded;
        }

        void ComplexObjects_Loaded(object sender, RoutedEventArgs e)
        {
            DataClasses1DataContext db = new DataClasses1DataContext();
            var emps = (from e in db.Employee
                        select e).ToList();
            listEmps.ItemsSource = emps;
            listEmps.DisplayMemberPath = "FirstName";
        }
    }
}