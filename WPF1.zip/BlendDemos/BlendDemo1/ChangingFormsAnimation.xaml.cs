﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Media.Animation;

namespace BlendDemo1
{
    /// <summary>
    /// Interaction logic for ChangingFormsAnimation.xaml
    /// </summary>
    public partial class ChangingFormsAnimation : Window
    {
        public ChangingFormsAnimation()
        {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            //ChangedForm changedForm = new ChangedForm();
            //changedForm.Show();
        }

        private void btnLeftMenuHide_Click(object sender, RoutedEventArgs e) 
        { 
            ShowHideMenu("sbHideLeftMenu", btnLeftMenuHide, btnLeftMenuShow, pnlLeftMenu); 
        }

        private void btnLeftMenuShow_Click(object sender, RoutedEventArgs e) 
        { 
            ShowHideMenu("sbShowLeftMenu", btnLeftMenuHide, btnLeftMenuShow, pnlLeftMenu); 
        }          
        
        private void btnTopMenuHide_Click(object sender, RoutedEventArgs e) 
        { 
            ShowHideMenu("sbHideTopMenu", btnTopMenuHide, btnTopMenuShow, pnlTopMenu); 
        }

        private void btnTopMenuShow_Click(object sender, RoutedEventArgs e) 
        { 
            ShowHideMenu("sbShowTopMenu", btnTopMenuHide, btnTopMenuShow, pnlTopMenu); 
        }          
        
        private void btnRightMenuHide_Click(object sender, RoutedEventArgs e) 
        { 
            ShowHideMenu("sbHideRightMenu", btnRightMenuHide, btnRightMenuShow, pnlRightMenu); 
        }         
        
        private void btnRightMenuShow_Click(object sender, RoutedEventArgs e) 
        { 
            ShowHideMenu("sbShowRightMenu", btnRightMenuHide, btnRightMenuShow, pnlRightMenu); 
        }

        private void btnBottomMenuHide_Click(object sender, RoutedEventArgs e) 
        { 
            ShowHideMenu("sbHideBottomMenu", btnBottomMenuHide, btnBottomMenuShow, pnlBottomMenu); 
        }         
        
        private void btnBottomMenuShow_Click(object sender, RoutedEventArgs e) 
        { 
            ShowHideMenu("sbShowBottomMenu", btnBottomMenuHide, btnBottomMenuShow, pnlBottomMenu); 
        }

        private void ShowHideMenu(string Storyboard, Button btnHide, Button btnShow, StackPanel pnl) 
        { 
            Storyboard sb = Resources[Storyboard] as Storyboard; 
            sb.Begin(pnl); 
            if (Storyboard.Contains("Show")) 
            { 
                btnHide.Visibility = System.Windows.Visibility.Visible; 
                btnShow.Visibility = System.Windows.Visibility.Hidden; 
            } 
            else if (Storyboard.Contains("Hide")) 
            { 
                btnHide.Visibility = System.Windows.Visibility.Hidden; 
                btnShow.Visibility = System.Windows.Visibility.Visible; 
            } 
        }
    }
}