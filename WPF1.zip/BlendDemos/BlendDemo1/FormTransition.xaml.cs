﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Media.Animation;

namespace BlendDemo1
{
    /// <summary>
    /// Interaction logic for ChangedForm.xaml
    /// </summary>
    public partial class FormTransition : Window
    {
        public FormTransition()
        {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            ShowHideMenu("sbShowSecondForm", firstScreen, secondScreen); 
        }

        private void ShowHideMenu(string Storyboard, Grid firstScreen, Grid secondScreen)
        {
            Storyboard sb = Resources[Storyboard] as Storyboard;
            sb.Duration = TimeSpan.Parse("0:0:3");
            firstScreen.Visibility = System.Windows.Visibility.Hidden;
            //sb.Begin(secondScreen);
        }
    }
}
