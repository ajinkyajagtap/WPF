﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace HelloWorld
{
    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            Application app = new Application();
            
            Window win = new Window();
            win.Height = 200;
            win.Width = 500;
            win.Title = "My First Application";
            //win.Content = "Hello World";

            SolidColorBrush scb = new SolidColorBrush();
            Color color = new Color();
            color.R = 255;
            color.G = 0;
            color.B = 0;
            color.A = 255;
            scb.Color = color;
            win.Background = scb;

            Button btn = new Button();
            btn.Height = 23;
            btn.Width = 75;
            btn.Content = "Click";
            btn.Click += btn_Click;

            win.Content = btn;

            app.Run(win);
        }

        static void btn_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Hello World");
        }
    }
}
