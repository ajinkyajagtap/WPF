﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataBindingDemo
{
    /// <summary>
    /// Interaction logic for DataBindingDemo3.xaml
    /// </summary>
    public partial class DataBindingDemo3 : Window
    {
        public DataBindingDemo3()
        {
            InitializeComponent();
            this.Loaded += DataBindingDemo3_Loaded;
        }

        void DataBindingDemo3_Loaded(object sender, RoutedEventArgs e)
        {
            List<Employee> employees = new List<Employee> { 
            new Employee{ FirstName = "Bruce", LastName = "Lee" },
            new Employee{ FirstName = "Jet", LastName = "Li" },
            new Employee{ FirstName = "Jackie", LastName = "Chan" }
            };
            lbx.ItemsSource = employees;
            lbx.DisplayMemberPath = "FirstName";
        }
    }
}
