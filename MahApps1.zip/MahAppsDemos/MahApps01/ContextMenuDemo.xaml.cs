﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MahApps01
{
    /// <summary>
    /// Interaction logic for ContextMenuDemo.xaml
    /// </summary>
    public partial class ContextMenuDemo : Window
    {
        public ContextMenuDemo()
        {
            InitializeComponent();
            this.Loaded += ContextMenuDemo_Loaded;
        }

        void ContextMenuDemo_Loaded(object sender, RoutedEventArgs e)
        {
            ObservableCollection<Employee> emps = new ObservableCollection<Employee>{
                new Employee{EmpID = 1, FirstName="Ajinkya", LastName="Jagtap"},
                new Employee{EmpID = 2, FirstName="Amol", LastName="Jagtap"},
                new Employee{EmpID = 3, FirstName="Amar", LastName="Jagtap"}
            };
            empGrid.ItemsSource = emps;
        }
    }

    public class Employee
    {
        public int EmpID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}