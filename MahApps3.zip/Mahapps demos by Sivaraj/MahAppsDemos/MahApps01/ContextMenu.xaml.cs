﻿using MahApps.Metro.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MahApps01
{
    /// <summary>
    /// Interaction logic for ContextMenu.xaml
    /// </summary>
    public partial class ContextMenu : MetroWindow
    {
        public ContextMenu()
        {
            InitializeComponent();
            this.Loaded += ContextMenu_Loaded;
        }

        void ContextMenu_Loaded(object sender, RoutedEventArgs e)
        {
            DataClasses1DataContext db = new DataClasses1DataContext();
            var query = (from prod in db.Products
                         select new ProductModel
                         {
                            ProductID =  prod.ProductID,
                            ProductName =  prod.ProductName,
                            ProductQty =  prod.QuantityPerUnit,
                            ProdcutReorderLevel = prod.ReorderLevel
                         }).ToList();

            dg.ItemsSource = query;
        }
    }

    public class ProductModel
    {
        public int ProductID { get; set; }
        public string ProductName { get; set;  }
        public string ProductQty { get; set; }
        public int? ProdcutReorderLevel { get; set; }
    }
}


